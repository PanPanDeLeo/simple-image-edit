const imageUploader = document.getElementById("imageUploader");
const originalCanvas = document.getElementById("originalCanvas");
const editedCanvas = document.getElementById("editedCanvas");

const originalContext = originalCanvas.getContext("2d");
const editedContext = editedCanvas.getContext("2d");

imageUploader.addEventListener("change", (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
        const img = new Image();
        img.onload = () => {
            originalCanvas.width = img.width;
            originalCanvas.height = img.height;
            editedCanvas.width = img.width;
            editedCanvas.height = img.height;

            originalContext.drawImage(img, 0, 0);
            editedContext.drawImage(img, 0, 0);
        };
        img.src = reader.result;
    };
    reader.readAsDataURL(file);
});

document.getElementById("grayscaleButton").addEventListener("click", () => {
    const imageData = editedContext.getImageData(0, 0, editedCanvas.width, editedCanvas.height);
    const pixels = imageData.data;

    for (let i = 0; i < pixels.length; i += 4) {
        const avg = (pixels[i] + pixels[i + 1] + pixels[i + 2]) / 3;
        pixels[i] = pixels[i + 1] = pixels[i + 2] = avg;
    }

    editedContext.putImageData(imageData, 0, 0);
});

document.getElementById("blurButton").addEventListener("click", () => {
    const imageData = editedContext.getImageData(0, 0, editedCanvas.width, editedCanvas.height);
    const pixels = imageData.data;
    const width = editedCanvas.width;
    const height = editedCanvas.height;

    const blurRadius = 2;

    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            let r = 0, g = 0, b = 0, count = 0;

            for (let dy = -blurRadius; dy <= blurRadius; dy++) {
                for (let dx = -blurRadius; dx <= blurRadius; dx++) {
                    const nx = x + dx;
                    const ny = y + dy;

                    if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
                        const index = (ny * width + nx) * 4;
                        r += pixels[index];
                        g += pixels[index + 1];
                        b += pixels[index + 2];
                        count++;
                    }
                }
            }

            const idx = (y * width + x) * 4;
            pixels[idx] = r / count;
            pixels[idx + 1] = g / count;
            pixels[idx + 2] = b / count;
        }
    }

    editedContext.putImageData(imageData, 0, 0);
});
